"""
Key Press vs Better Key Press

In the video Keyboard Inputs, we discuss how to move an object using the keyboard.
The code from the video is included below.

This is not the best way to implement this. For example, if I press both
left and right arrow keys at the "same time", it will go in the latest direction
that is detected. The better way is to have the two cancel so that the object doesn't
move if both left/right(or up/down) are pressed and held down.

Compare this code to the better_key_press module. 

You do not need to write code for this.

"""



import arcade

WIDTH = 800
HEIGHT = 600


class GameWindow(arcade.Window):
    def __init__(self, width, height, title):
        super().__init__(width, height, title)
        arcade.set_background_color(arcade.color.WHITE)

        self.center_x = width/2
        self.center_y = height/2

        self.change_x = 0
        self.change_y = 0



    def on_draw(self):
        """ Called automatically 60 times a second to draw objects."""
        arcade.start_render()
        arcade.draw_rectangle_filled(self.center_x, self.center_y, 40, 40, arcade.color.BLUE)

    def update(self, delta_time):
        """ Called automatically 60 times a second to update our objects."""
        self.center_x += self.change_x
        self.center_y += self.change_y    

    def on_key_press(self, key, modifiers):
        """ Called automatically whenever a key is pressed. """
        if key == arcade.key.LEFT:
            self.change_x = -5
        elif key == arcade.key.RIGHT:
            self.change_x = 5
        elif key == arcade.key.UP:
            self.change_y = 5 
        elif key == arcade.key.DOWN:
            self.change_y = -5

    def on_key_release(self, key, modifiers):
        """ Called automatically whenever a key is released. """
        if key == arcade.key.LEFT:
            self.change_x = 0
        elif key == arcade.key.RIGHT:
            self.change_x = 0
        elif key == arcade.key.UP:
            self.change_y = 0 
        elif key == arcade.key.DOWN:
            self.change_y = 0


def main():
    """ Main method """
    window = GameWindow(WIDTH, HEIGHT, "Key Press")
    arcade.run()


if __name__ == "__main__":
    main()







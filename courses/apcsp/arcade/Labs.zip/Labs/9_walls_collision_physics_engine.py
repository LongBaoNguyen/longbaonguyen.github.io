import arcade

WIDTH = 800
HEIGHT = 600

class GameWindow(arcade.Window):
    def __init__(self, width, height, title):
        super().__init__(width, height, title)
        arcade.set_background_color(arcade.color.WHITE)

        # initialize tank and tank_list and brick_list variables
        # use tank.png and brick.png

        
        # populate SpriteList with brick Sprites.
        for x in range(100, 700, 64):
            brick = arcade.Sprite("images/brick.png", 0.5, center_x=x, center_y=200)
            self.brick_list.append(brick)

        # initialize the physics engine    


    def on_draw(self):
        """ Called automatically 60 times a second to draw objects."""
        arcade.start_render()

        # draw tank_list and brick_list
    
    def on_update(self, delta_time):
        """ Called automatically 60 times a second to update objects.
            delta_time is time since the last time on_update was called."""
        
        # call update on physics engine
        # this one line of code replaces algorithm from lab 7_walls_collisions.

        
    def on_key_press(self, key, modifiers):
        """ Called automatically whenever a key is pressed. """
        if key == arcade.key.LEFT:
            self.tank.change_x = -5
        elif key == arcade.key.RIGHT:
            self.tank.change_x = 5
        elif key == arcade.key.UP:
            self.tank.change_y = 5
        elif key == arcade.key.DOWN:
            self.tank.change_y = -5

    def on_key_release(self, key, modifiers):
        """ Called automatically whenever a key is released. """    
        if key == arcade.key.LEFT:
            self.tank.change_x = 0
        elif key == arcade.key.RIGHT:
            self.tank.change_x = 0
        elif key == arcade.key.UP:
            self.tank.change_y = 0
        elif key == arcade.key.DOWN:
            self.tank.change_y = 0
    
    
def main():
    """ Main method """
    window = GameWindow(WIDTH, HEIGHT, "Resolving Many-Wall Collisions with Engine")
    arcade.run()


if __name__ == "__main__":
    main()





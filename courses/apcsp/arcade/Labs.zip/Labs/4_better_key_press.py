"""
Key Press vs Better Key Press

In the video Keyboard Inputs, we discuss how to move an object using the keyboard.
This method from the vido is not the best way to implement this. For example, if I press both
left and right arrow keys at the "same time", it will go in the latest direction
that is detected. The better way is to have the two cancel so that the object doesn't
move if both left/right(or up/down) are pressed and held down.

The code below is the better way to implement key_press. Read it and
compare it to the key_press module.

You do not need to write code for this.
"""

import arcade

WIDTH = 800
HEIGHT = 600

SPEED = 5

class GameWindow(arcade.Window):
    def __init__(self, width, height, title):
        super().__init__(width, height, title)
        arcade.set_background_color(arcade.color.WHITE)

        self.center_x = width/2
        self.center_y = height/2

        self.change_x = 0
        self.change_y = 0
        
        self.left_pressed = False
        self.right_pressed = False
        self.up_pressed = False
        self.down_pressed = False


    def on_draw(self):
        """ Called automatically 60 times a second to draw objects."""
        arcade.start_render()
        arcade.draw_rectangle_filled(self.center_x, self.center_y, 40, 40, arcade.color.BLUE)

    def update(self, delta_time):
        """ Called automatically 60 times a second to update our objects."""
        self.center_x += self.change_x
        self.center_y += self.change_y    

        self.change_x = 0
        self.change_y = 0

        if self.up_pressed and not self.down_pressed:
            self.change_y = SPEED
        elif self.down_pressed and not self.up_pressed:
            self.change_y = -SPEED
        if self.left_pressed and not self.right_pressed:
            self.change_x = -SPEED
        elif self.right_pressed and not self.left_pressed:
            self.change_x = SPEED

    def on_key_press(self, key, modifiers):
        """ Called automatically whenever a key is pressed. """
        if key == arcade.key.UP:
            self.up_pressed = True
        elif key == arcade.key.DOWN:
            self.down_pressed = True
        elif key == arcade.key.LEFT:
            self.left_pressed = True
        elif key == arcade.key.RIGHT:
            self.right_pressed = True

    def on_key_release(self, key, modifiers):
        """ Called automatically whenever a key is released. """
        if key == arcade.key.UP:
            self.up_pressed = False
        elif key == arcade.key.DOWN:
            self.down_pressed = False
        elif key == arcade.key.LEFT:
            self.left_pressed = False
        elif key == arcade.key.RIGHT:
            self.right_pressed = False

def main():
    """ Main method """
    window = GameWindow(WIDTH, HEIGHT, "Key Press")
    arcade.run()


if __name__ == "__main__":
    main()







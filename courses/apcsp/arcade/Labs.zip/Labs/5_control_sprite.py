"""
Controlling a Sprite. Movement and Rotation.

Read the key_press vs better_key_press modules and decide on which one you like to 
implement for your games. (For simplicity, I just use key_press on my videos.)

Then use the code to control a Sprite object(images/tank.png). The Sprite object
will move up/down/left/right and rotate if 'a' or 's' is pressed. 
"""



import arcade

WIDTH = 800
HEIGHT = 600

class GameWindow(arcade.Window):
    def __init__(self, width, height, title):
        super().__init__(width, height, title)
        arcade.set_background_color(arcade.color.WHITE)

        # image from imaginelabs.rocks
        # create a Sprite object(use tank.png)
        # initialize it to some position on the screen.
        


    def on_draw(self):
        """ Called automatically 60 times a second to draw objects."""
        arcade.start_render()

        # draw the Sprite

    def on_update(self, delta_time):
        """ Called automatically 60 times a second to update our objects."""
        
        # call update() on the Sprite

    def on_key_press(self, key, modifiers):
        """ Called automatically whenever a key is pressed. """
        
        # implement movement, see key_press or better_key_press.



        # implement rotation, if press 'a', rotate clockwise 90 degrees
        # if press 's', rotate it counterclockwise 90 degrees
        
        


    def on_key_release(self, key, modifiers):
        """ Called automatically whenever a key is released. """
        
        # implement key release

def main():
    """ Main method """
    window = GameWindow(WIDTH, HEIGHT, "Sprites")
    arcade.run()


if __name__ == "__main__":
    main()





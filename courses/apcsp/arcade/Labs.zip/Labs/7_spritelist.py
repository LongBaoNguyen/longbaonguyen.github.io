"""
Working with multiple Sprites: SpriteList
We can store a list of Sprites in a SpriteList. This will optimize drawing them.
Instead of drawing individually, SpriteList draws them in parallel, all at once.
By using SpriteList, Arcade is capable of drawing hundreds of thousands of 
static Sprites at the same time!

Use the brick.png image to create a list of Sprites by using a for loop. 
Put them in a SpriteList. Then draw them.

"""


import arcade

WIDTH = 800
HEIGHT = 600


class GameWindow(arcade.Window):
    def __init__(self, width, height, title):
        super().__init__(width, height, title)
        arcade.set_background_color(arcade.color.WHITE)

        # create brick_list and initialize it as a SpriteList
        # use brick.png

        # use a for loop to create a brick Sprite and place them adjacent 
        # to each other horizontally, add each Sprite to the SpriteList.


    


    def on_draw(self):
        """ Called automatically 60 times a second to draw objects."""
        arcade.start_render()
        # call draw on the SpriteList

    def on_update(self, delta_time):
        """ Called automatically 60 times a second to update objects.
            delta_time is time since the last time on_update was called."""

        # nothing is moving, so need to update
        pass
        
    def on_key_press(self, key, modifiers):
        """ Called automatically whenever a key is pressed. """
        pass

    def on_key_release(self, key, modifiers):
        """ Called automatically whenever a key is released. """    
        pass
  
def main():
    """ Main method """
    window = GameWindow(WIDTH, HEIGHT, "SpriteList")
    arcade.run()


if __name__ == "__main__":
    main()





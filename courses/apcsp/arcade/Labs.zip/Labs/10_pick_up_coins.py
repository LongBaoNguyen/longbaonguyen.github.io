"""
Pick up Coins.

Start with the code from lab 8_wall_collisions and add a list of coins.
As the tank moves around the screen, it can pick up the coin and remove it 
from the screen. There should be a counter(text) that displays the number of
coins picked up.

"""

import arcade

WIDTH = 800
HEIGHT = 600


class GameWindow(arcade.Window):
    def __init__(self, width, height, title):
        super().__init__(width, height, title)
        arcade.set_background_color(arcade.color.WHITE)

        self.tank = arcade.Sprite("images/tank.png")
        self.tank_list = arcade.SpriteList()
        self.tank_list.append(self.tank)
        self.brick_list = arcade.SpriteList()

        # initialize coin_list

        # initialize variable num_coins to keep track of number of coins picked up


        for x in range(100, 700, 64):
            brick = arcade.Sprite("images/brick.png", 0.5, center_x=x, center_y=200)
            self.brick_list.append(brick)

        # physics engine            
        self.physics_engine = arcade.PhysicsEngineSimple(self.tank, self.brick_list)



    def on_draw(self):
        """ Called automatically 60 times a second to draw objects."""
        arcade.start_render()
        self.tank_list.draw()
        self.brick_list.draw()

        # draw coin_list


        # draw text to show the number of coins picked up
    
    def on_update(self, delta_time):
        """ Called automatically 60 times a second to update objects.
            delta_time is time since the last time on_update was called."""
        self.physics_engine.update()

        # call check_for_collision_with_list to get collision list
        # between tank and coin_list

        # for each coin in the collision list
        # call remove_from_sprite_lists() to remove it from screen
        # (or alternatively kill() will also work)
        # update the number of coins picked up.
            
        

        
    def on_key_press(self, key, modifiers):
        """ Called automatically whenever a key is pressed. """
        if key == arcade.key.LEFT:
            self.tank.change_x = -5
        elif key == arcade.key.RIGHT:
            self.tank.change_x = 5
        elif key == arcade.key.UP:
            self.tank.change_y = 5
        elif key == arcade.key.DOWN:
            self.tank.change_y = -5

    def on_key_release(self, key, modifiers):
        """ Called automatically whenever a key is released. """    
        if key == arcade.key.LEFT:
            self.tank.change_x = 0
        elif key == arcade.key.RIGHT:
            self.tank.change_x = 0
        elif key == arcade.key.UP:
            self.tank.change_y = 0
        elif key == arcade.key.DOWN:
            self.tank.change_y = 0
    
    
def main():
    """ Main method """
    window = GameWindow(WIDTH, HEIGHT, "Pick Up Coins")
    arcade.run()


if __name__ == "__main__":
    main()





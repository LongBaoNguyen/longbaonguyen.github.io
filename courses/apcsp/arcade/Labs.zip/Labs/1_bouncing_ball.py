"""
Bouncing Ball Lab
In the video Bouncing Ball, we saw how to simulate a ball bouncing back and forth
in one dimension. Fill in the code below so that the ball bounces in two dimension
by adding both x and y velocity components. Make it bounce off the four boundary
walls. 
"""

import arcade

WIDTH = 800
HEIGHT = 600


class GameWindow(arcade.Window):
    def __init__(self, width, height, title):
        super().__init__(width, height, title)
        arcade.set_background_color(arcade.color.WHITE)

        # initialize variables for ball(position, velocity and radius)
        self.center_x = WIDTH/2
        self.center_y = HEIGHT/2
        

    def on_draw(self):
        """ Called automatically 60 times a second to draw objects."""
        arcade.start_render()
        
        # draw circle 
        arcade.draw_circle_filled(self.center_x, self.center_y, 100, arcade.color.BABY_BLUE_EYES)

    def on_update(self, delta_time):
        """ Called to update our objects. Happens approximately 60 times per second."""
        
        # add velocity vector to position vector to move one frame
        self.center_x += 5
        self.center_y += 3
        # if ball leaves left or right side, negate x-velocity.  


        # if ball leaves top or bottom side, negate y-velocity.  



def main():
    """ Main method """
    window = GameWindow(WIDTH, HEIGHT, "Bouncing Ball")
    arcade.run()


if __name__ == "__main__":
    main()
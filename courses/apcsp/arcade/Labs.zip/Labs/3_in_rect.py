"""
In Rectangle? Lab

This is similar to the previous lab. Draw a rectangle in the middle of the screen of 
some width and height and color.
If the mouse enters the rectangle, change color. If the mouse leaves the rectangle,
reset to original color.

"""

import arcade
import math

WIDTH = 800
HEIGHT = 600


class GameWindow(arcade.Window):
    def __init__(self, width, height, title):
        super().__init__(width, height, title)
        arcade.set_background_color(arcade.color.WHITE)
        
        # initialize width, height and color of rectangle
        # You don't need variables for center of rectangle since it will not move.


    def on_draw(self):
        """ Called automatically 60 times a second to draw objects."""
        arcade.start_render()

        # draw rectangle at center of screen


    def on_update(self, delta_time):
        """ Called to update our objects. Happens approximately 60 times per second."""
        
        # rectangle is not moving, so no need to update any objects
        pass

    def on_mouse_motion(self, x, y, dx, dy):
        """ Called automatically 60 times a second to detect mouse motion."""
        
        # if x is within the x-bounds of the rectangle and
        # if y is within the y-bounds of the rectangle then 
        # change color else set to original color.

    

def main():
    """ Main method """
    window = GameWindow(WIDTH, HEIGHT, "Inside Rectangle")
    arcade.run()


if __name__ == "__main__":
    main()
"""
In Circle? Lab

Draw a circle in the middle of the screen of some radius and color.
If the mouse enters the circle, change color. If the mouse leaves the circle,
reset to original color.

Implement the function distance(see below, right above main) which accepts 
four arguments x1, y1, x2 and y2 and returns the distance between 
(x1, y1) and (x2, y2). 
"""

import arcade
import math

WIDTH = 800
HEIGHT = 600


class GameWindow(arcade.Window):
    def __init__(self, width, height, title):
        super().__init__(width, height, title)
        arcade.set_background_color(arcade.color.WHITE)

        # initialize radius and color of circle. 
        # You don't need variables for center of circle since it will not move.
        


    def on_draw(self):
        """ Called automatically 60 times a second to draw objects."""
        arcade.start_render()

        # draw circle at the center of the screen, use WIDTH and HEIGHT.



    def on_update(self, delta_time):
        """ Called to update our objects. Happens approximately 60 times per second."""
        
        # the ball is not moving so no updates needed.
        pass

    def on_mouse_motion(self, x, y, dx, dy):
        """ Called automatically 60 times a second to detect mouse motion."""
        
        # call distance function below to check if distance is less than or equal to radius
        # if it is, change color else set to original color.
        


def distance(x1, y1, x2, y2):
    """ Use Pythagorean distance formula.
        Returns distance between (x1, y1) and (x2, y2). 
    """
    pass

def main():
    """ Main method """
    window = GameWindow(WIDTH, HEIGHT, "Inside Circle")
    arcade.run()


if __name__ == "__main__":
    main()
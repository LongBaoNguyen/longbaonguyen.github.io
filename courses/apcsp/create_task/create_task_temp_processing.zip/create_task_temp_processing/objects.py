"""
Name: 

Title of Create Task:     
   
"""

from __future__ import division, print_function
import arcade
from constants import *
import random

class Window:    
    def __init__(self):
        """ Declare and initialize your variables. """


    def on_draw(self):
        """ Called automatically 60 times a second to draw objects."""

    def on_update(self):
        """ Called to update our objects. Happens approximately 60 times per second."""
        
        
    def sub_algorithm_1(self, a, b):
        """ Rename this subalgorithm 1 and modify its parameters. 
            Modify this comment to reflect your subalgorithm.
        """
        pass
        
                        

    def sub_algorithm_2(self, a, b):     
        """ Rename this subalgorithm 1 and modify its parameters. 
            Modify this comment to reflect your subalgorithm.
        """
        pass
   
    def on_key_press(self, key):
        """ Called automatically whenever a key is pressed. """
        pass
        # if key == LEFT:
        #     self.player.change_x = -5
        # elif key == RIGHT:
        #     self.player.change_x = 5
        # elif key == UP:
        #     self.player.change_y = -5 
        # elif key == DOWN:
        #     self.player.change_y = 5
        

    def on_key_release(self, key):
        """ Called automatically whenever a key is released. """
        pass
        # if key == LEFT:
        #     self.player.change_x = 0
        # elif key == RIGHT:
        #     self.player.change_x = 0
        # elif key == UP:
        #     self.player.change_y = 0
        # elif key == DOWN:
        #     self.player.change_y = 0
            
    def on_mouse_motion(self, x, y, dx, dy):        
        """ Called whenever the mouse moves. """
        # if x is within width of rectangle and y within height of rectangle
        # return True otherwise return False.
        pass
        
    def on_mouse_press(self, x, y, button):
        """ Called whenever the mouse is pressed. """
        pass
        
    def on_mouse_release(self, x, y, button):
        """ Called whenever the mouse is released. """
        pass
                  
      
        
        
    
